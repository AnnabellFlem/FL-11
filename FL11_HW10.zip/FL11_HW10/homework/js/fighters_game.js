class Fighter {
    constructor({ name, damage, hp, agility }) {
        this._name = name;
        this._damage = damage;
        this._hp = hp;
        this._maxhp = hp;
        this._agility = agility;
        this._wins = 0;
        this._losses = 0;
    }
     getName() {
         return this._name;
     }
// let name = myFighter.getName();
// console.log(name); // John

    getDamage() {
        return this._damage;
    }
// let damage = myFighter.getDamage();
// console.log(damage); // 20

getAgility() {
    return this._agility;
}
// let agility = myFighter.getAgility();
// console.log(agility); // 25

    getHealth() {
        return this._hp;
    }
// let health = myFighter.getHealth();
// console.log(health); // 100

// setHealth(hp) {
//     this._hp = hp;
// }

// getWins() {
//     return this._wins;
// }
// getLosses() {
//     return this._losses;
// }

getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

    attack(fighter) {
        const maxLimit = 100;
        const random = this.getRandomInt(0, maxLimit + 1);
        const probabilityAttack = maxLimit - fighter.getAgility();
        if (probabilityAttack <= random || !probabilityAttack) { //!probabilityAttack
//            this._wins;            
            console.log(`${fighter.getName()} attack missed`);
        } else {
            fighter.dealDamage(this.getDamage());
            console.log(`${this.getName()} make ${this.getDamage()} damage to ${fighter.getName()}`);
        }
    }

//    myFighter.attack(myFighter2);
// John make 20 damage to Jack
//myFighter2.attack(myFighter);
// Jack attack missed

logCombatHistory() {
    return `Name: ${this.getName()}, Wins: ${this.getWins()}, Losses: ${this.getLosses()}`;
}

heal(hp) { 
    this._hp = Math.min(this._hp + hp, this._maxhp);
}

dealDamage(hp) {
    this._hp = Math.max(0, this._hp - hp);
}

addWin() {
    this._wins++;
}

addLoss() {
    this._losses++;
}

battle(fighter1, fighter2) {
//
}

}

// const myFighter = new Fighter({name: 'John', damage: 20, hp: 100, agility: 25}); // returns an object with methods

// let name1 = myFighter.name;
// console.log(name1); 


